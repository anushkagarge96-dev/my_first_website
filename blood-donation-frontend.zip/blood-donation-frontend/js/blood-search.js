document.getElementById("searchForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const bloodGroup = document.getElementById("bloodGroup").value;
    const location = document.getElementById("location").value.toLowerCase().trim();

    fetch("http://localhost:8080/donors")
        .then(response => response.json())
        .then(donors => {

            const availableDonors = donors.filter(donor =>
                donor.bloodGroup === bloodGroup &&
                donor.availability === true &&
                donor.address.toLowerCase().includes(location)
            );

            const results = document.getElementById("results");

            if (availableDonors.length === 0) {
                results.innerHTML = "<p>No available donors found in this location.</p>";
                return;
            }

            results.innerHTML = "<h2>Available Donors</h2>";

            availableDonors.forEach(donor => {

                results.innerHTML += `
                    <div class="donor-card">
                        <p><b>Name:</b> ${donor.name}</p>
                        <p><b>Blood Group:</b> ${donor.bloodGroup}</p>
                        <p><b>Mobile:</b> ${donor.mobile}</p>
                        <p><b>Address:</b> ${donor.address}</p>
                        <p><b>Availability:</b> Yes</p>
                    </div>
                `;

            });

        })
        .catch(error => {
            console.error("Error:", error);
            alert("Unable to connect to server.");
        });

});