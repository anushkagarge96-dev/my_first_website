let loggedInDonor = null;


// Load Donor Details
fetch("http://localhost:8080/donors")
    .then(response => response.json())
    .then(donors => {

        // Get email saved during login
        const email = localStorage.getItem("donorEmail");

        // Find the donor
        loggedInDonor = donors.find(d => d.email === email);

        if (loggedInDonor) {

            document.getElementById("donorName").textContent =
                loggedInDonor.name;

            document.getElementById("donorEmail").textContent =
                loggedInDonor.email;

            document.getElementById("donorMobile").textContent =
                loggedInDonor.mobile;

            document.getElementById("donorBloodGroup").textContent =
                loggedInDonor.bloodGroup;

            document.getElementById("donorAvailability").textContent =
                loggedInDonor.availability ? "Available" : "Not Available";

        } else {

            alert("Please login first.");
            window.location.href = "login.html";
        }

    })
    .catch(error => {

        console.error("Error:", error);
        alert("Unable to connect to server.");

    });


// Logout
function logout() {

    localStorage.removeItem("donorEmail");

    alert("Logged out successfully!");

    window.location.href = "login.html";
}


// Edit Profile
function editProfile() {

    // Check donor details
    if (!loggedInDonor) {

        alert("Donor details are still loading. Please wait.");
        return;
    }


    // Check Edit Profile Form
    const editForm = document.getElementById("editProfileForm");

    if (!editForm) {

        alert("Edit Profile form not found.");
        return;
    }


    // Fill Edit Profile Form

    document.getElementById("editName").value =
        loggedInDonor.name || "";

    document.getElementById("editEmail").value =
        loggedInDonor.email || "";

    document.getElementById("editMobile").value =
        loggedInDonor.mobile || "";

    document.getElementById("editAge").value =
        loggedInDonor.age || "";

    document.getElementById("editGender").value =
        loggedInDonor.gender || "";

    document.getElementById("editBloodGroup").value =
        loggedInDonor.bloodGroup || "";

    document.getElementById("editAddress").value =
        loggedInDonor.address || "";

    document.getElementById("editAvailability").value =
        loggedInDonor.availability ? "true" : "false";

    document.getElementById("editLastDonationDate").value =
        loggedInDonor.lastDonationDate || "";


    // Show Edit Profile Form
    editForm.style.display = "block";
}