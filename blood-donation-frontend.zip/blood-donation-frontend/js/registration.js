document.getElementById("registrationForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const form = document.getElementById("registrationForm");

    const donor = {
        name: form.elements["name"].value,
        email: form.elements["email"].value,
        password: form.elements["password"].value,
        mobile: form.elements["mobile"].value,
        age: form.elements["age"].value,
        gender: form.elements["gender"].value,
        bloodGroup: form.elements["bloodGroup"].value,
        address: form.elements["address"].value,
        availability: form.elements["availability"].value,
        lastDonationDate: form.elements["lastDonationDate"].value
    };

    console.log("Donor data:", donor);

    fetch("http://localhost:8080/donors", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(donor)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Registration failed");
        }
        return response.json();
    })
    .then(data => {
        console.log("Registered donor:", data);
        alert("Donor Registration Successful!");
        form.reset();
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Registration failed. Make sure Spring Boot is running.");
    });

});