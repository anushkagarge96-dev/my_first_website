const email = localStorage.getItem("donorEmail");

if (!email) {
    alert("Please login first.");
    window.location.href = "login.html";
}

let donorId = null;

// Get all donors and find the logged-in donor
fetch("http://localhost:8080/donors")
    .then(response => response.json())
    .then(donors => {

        const donor = donors.find(d => d.email === email);

        if (!donor) {
            alert("Donor not found.");
            window.location.href = "login.html";
            return;
        }

        donorId = donor.donorId;

        // Fill existing donor information
        document.getElementById("name").value = donor.name;
        document.getElementById("email").value = donor.email;
        document.getElementById("mobile").value = donor.mobile;
        document.getElementById("age").value = donor.age;
        document.getElementById("gender").value = donor.gender;
        document.getElementById("bloodGroup").value = donor.bloodGroup;
        document.getElementById("address").value = donor.address;
        document.getElementById("availability").value = donor.availability;
        document.getElementById("lastDonationDate").value =
            donor.lastDonationDate || "";

    })
    .catch(error => {
        console.error("Error:", error);
        alert("Unable to connect to server.");
    });


// Update donor
document.getElementById("editProfileForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const updatedDonor = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        mobile: document.getElementById("mobile").value,
        age: document.getElementById("age").value,
        gender: document.getElementById("gender").value,
        bloodGroup: document.getElementById("bloodGroup").value,
        address: document.getElementById("address").value,
        availability: document.getElementById("availability").value,
        lastDonationDate: document.getElementById("lastDonationDate").value
    };

    fetch(`http://localhost:8080/donors/${donorId}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(updatedDonor)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Update failed");
        }
        return response.json();
    })
    .then(data => {

        console.log("Updated donor:", data);

        // Update stored email if email was changed
        localStorage.setItem("donorEmail", data.email);

        alert("Profile Updated Successfully!");

        window.location.href = "dashboard.html";
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Profile update failed.");
    });

});