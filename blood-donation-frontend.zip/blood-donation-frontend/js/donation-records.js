const API_URL = "http://localhost:8080/donations";

async function loadDonationRecords() {
    const tableBody = document.getElementById("donationTableBody");

    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Failed to fetch donation records");
        }

        const donations = await response.json();

        tableBody.innerHTML = "";

        if (donations.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6">No donation records found.</td>
                </tr>
            `;
            return;
        }

        donations.forEach(donation => {
            const row = `
                <tr>
                    <td>${donation.donationId || ""}</td>
                    <td>${donation.date || ""}</td>
                    <td>${donation.bloodGroup || ""}</td>
                    <td>${donation.units || ""}</td>
                    <td>${donation.hospital || ""}</td>
                    <td>${donation.status || ""}</td>
                </tr>
            `;

            tableBody.innerHTML += row;
        });

    } catch (error) {
        console.error("Error loading donations:", error);

        tableBody.innerHTML = `
            <tr>
                <td colspan="6">
                    Unable to load donation records.
                </td>
            </tr>
        `;
    }
}

loadDonationRecords();