document.getElementById("loginForm").addEventListener("submit", function(event) {


event.preventDefault();

const email = document.getElementById("email").value;
const password = document.getElementById("password").value;

fetch("http://localhost:8080/donors")
    .then(response => response.json())
    .then(donors => {

        const donor = donors.find(d =>
            d.email === email && d.password === password
        );

        if (donor) {

            alert("Login Successful!");

            console.log("Logged in donor:", donor);

            // Save donor ID
            localStorage.setItem("donorId", donor.donorId);

            // Save donor email
            localStorage.setItem("donorEmail", donor.email);

            // Check saved ID
            console.log("Saved Donor ID:", localStorage.getItem("donorId"));

            // Open donor dashboard
            window.location.href = "dashboard.html";

        } else {

            alert("Invalid Email or Password");
        }

    })
    .catch(error => {

        console.error("Login Error:", error);

        alert("Unable to connect to server. Please start Spring Boot.");
    });


});
