const requestForm = document.getElementById("requestForm");
const message = document.getElementById("message");

requestForm.addEventListener("submit", async function (event) {

    event.preventDefault();

    const requestData = {
        patientName: document.getElementById("patientName").value,
        bloodGroup: document.getElementById("bloodGroup").value,
        units: parseInt(document.getElementById("units").value),
        hospitalName: document.getElementById("hospitalName").value,
        hospitalAddress: document.getElementById("hospitalAddress").value,
        contactNumber: document.getElementById("contactNumber").value
    };

    try {

        const response = await fetch("http://localhost:8080/requests", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(requestData)
        });

        if (response.ok) {

            alert("Blood request submitted successfully!");

            message.innerText = "Blood request submitted successfully!";
            message.style.color = "green";

            requestForm.reset();

        } else {

            alert("Failed to submit blood request.");

            message.innerText = "Failed to submit blood request.";
            message.style.color = "red";
        }

    } catch (error) {

        console.error(error);

        alert("Server error. Please start Spring Boot.");

        message.innerText = "Server error. Please start Spring Boot.";
        message.style.color = "red";
    }

});